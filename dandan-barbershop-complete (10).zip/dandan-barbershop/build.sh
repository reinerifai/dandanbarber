#!/bin/bash
set -e

echo "Installing dependencies..."
pnpm install

echo "Building application..."
pnpm run build

echo "Build completed successfully!"
